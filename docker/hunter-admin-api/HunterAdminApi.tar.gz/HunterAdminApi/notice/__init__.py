#!/ usr/bin/env
# coding=utf-8
"""
author: b5mali4
Copyright (c) 2018
License: BSD, see LICENSE for more details.
消息通知，可以接入钉钉，邮件，或者其他安全管理运营平台
"""