/**
 * Created by b5mali4 on 2019/3/12.
 */
console.log("panel.js");